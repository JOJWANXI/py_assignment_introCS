from __future__ import annotations

from abc import abstractmethod, ABC
from material import Material
from material import RANDOM_MATERIAL_NAMES
from random_gen import RandomGen
from aset import ASet
from heap import MaxHeap
from bst import BinarySearchTree
from bst import BSTInOrderIterator

# Generated with https://www.namegenerator.co/real-names/english-name-generator
TRADER_NAMES = [
    "Pierce Hodge",
    "Loren Calhoun",
    "Janie Meyers",
    "Ivey Hudson",
    "Rae Vincent",
    "Bertie Combs",
    "Brooks Mclaughlin",
    "Lea Carpenter",
    "Charlie Kidd",
    "Emil Huffman",
    "Letitia Roach",
    "Roger Mathis",
    "Allie Graham",
    "Stanton Harrell",
    "Bert Shepherd",
    "Orson Hoover",
    "Lyle Randall",
    "Jo Gillespie",
    "Audie Burnett",
    "Curtis Dougherty",
    "Bernard Frost",
    "Jeffie Hensley",
    "Rene Shea",
    "Milo Chaney",
    "Buck Pierce",
    "Drew Flynn",
    "Ruby Cameron",
    "Collie Flowers",
    "Waldo Morgan",
    "Winston York",
    "Dollie Dickson",
    "Etha Morse",
    "Dana Rowland",
    "Eda Ryan",
    "Audrey Cobb",
    "Madison Fitzpatrick",
    "Gardner Pearson",
    "Effie Sheppard",
    "Katherine Mercer",
    "Dorsey Hansen",
    "Taylor Blackburn",
    "Mable Hodge",
    "Winnie French",
    "Troy Bartlett",
    "Maye Cummings",
    "Charley Hayes",
    "Berta White",
    "Ivey Mclean",
    "Joanna Ford",
    "Florence Cooley",
    "Vivian Stephens",
    "Callie Barron",
    "Tina Middleton",
    "Linda Glenn",
    "Loren Mcdaniel",
    "Ruby Goodman",
    "Ray Dodson",
    "Jo Bass",
    "Cora Kramer",
    "Taylor Schultz",
]


class Trader(ABC):

    def __init__(self, name: str) -> None:
        self.name = name
        self.current_material = None
        self.current_price = 0
        self.all_materials = None

    @classmethod
    def random_trader(cls) -> object:
        name = RandomGen.random_choice(TRADER_NAMES)
        return cls(name)

    @abstractmethod
    def set_all_materials(self, mats: list[Material]) -> None:
        pass

    @abstractmethod
    def add_material(self, mat: Material) -> None:
        pass

    @abstractmethod
    def remove_material(self, mat: Material):  # will remove the material from the inventory of the trader
        pass

    def is_currently_selling(self) -> bool:
        if self.current_material is None:
            return False
        else:
            return True

    def current_deal(self) -> tuple[Material, float]:
        if self.is_currently_selling():
            return self.current_material, self.current_price
        else:
            raise ValueError()

    @abstractmethod
    def generate_deal(self) -> None:
        pass

    def generate_price(self):
        self.current_price = round(2 + 8 * RandomGen.random_float(), 2)

    def stop_deal(self) -> None:
        self.current_material = None  # stop_deal will make current_deal return None

    def get_str(self):
        return "{} buying {} for {}💰".format(self.name, str(self.current_material), self.current_price)

    def __str__(self) -> str:
        return "<Trader: " + self.get_str() + ">"


class RandomTrader(Trader):

    def __init__(self, name: str):
        super().__init__(name)
        self.all_materials = []

    @classmethod
    def random_trader(cls) -> RandomTrader:
        name = RandomGen.random_choice(TRADER_NAMES)
        return cls(name)

    def set_all_materials(self, mats: list[Material]) -> None:
        self.all_materials = []
        for mat in mats:
            self.add_material(mat)

    def add_material(self, mat: Material) -> None:
        self.all_materials.append(mat)

    def remove_material(self, mat: Material):
        self.all_materials.remove(mat)

    def generate_deal(self) -> None:
        self.current_material = RandomGen.random_choice(self.all_materials)
        self.generate_price()

    def __str__(self) -> str:
        return "<RandomTrader: " + self.get_str() + ">"

class RangeTrader(Trader):

    def __init__(self, name: str):
        super().__init__(name)
        self.all_materials = BinarySearchTree()

    def set_all_materials(self, mats: list[Material]) -> None:
        self.all_materials = BinarySearchTree()
        for mat in mats:
            self.add_material(mat)

    def add_material(self, mat: Material) -> None:
        self.all_materials.root = self.all_materials.insert_aux(self.all_materials.root, mat.mining_rate, mat)

    def remove_material(self, mat: Material):
        self.all_materials.delete_aux(self.all_materials.root, mat.mining_rate)

    def materials_between(self, i: int, j: int) -> list[Material]:
        k = 0
        result = []
        for key in self.all_materials:
            if i <= k <= j:
                result.append(self.all_materials[key])
            k += 1
        return result

    def generate_deal(self) -> None:
        i = RandomGen.randint(0, self.all_materials.length - 1)
        j = RandomGen.randint(i, self.all_materials.length - 1)
        materials = self.materials_between(i, j)
        self.current_material = RandomGen.random_choice(materials)
        super().generate_price()

    def __str__(self) -> str:
        return "<RangeTrader: " + self.get_str() + ">"

class HardTrader(Trader):

    def __init__(self, name: str):
        super().__init__(name)
        self.all_materials = MaxHeap(Material.get_material_count())

    def set_all_materials(self, mats: list[Material]) -> None:
        self.all_materials = MaxHeap(len(mats))
        for material in mats:
            self.all_materials.add(material)

    def add_material(self, mat: Material) -> None:
        self.all_materials.add(mat)

    def remove_material(self, mat: Material):
        pass

    def generate_deal(self) -> None:
        self.current_material = self.all_materials.get_max()
        self.generate_price()

    def __str__(self) -> str:
        return "<HardTrader: " + self.get_str() + ">"

if __name__ == "__main__":
    trader = RangeTrader("Jackson")
    print(trader)
    trader.set_materials([
        Material("Coal", 4.5),
        Material("Diamonds", 3),
        Material("Redstone", 20),
    ])
    trader.generate_deal()
    print(trader)
    trader.stop_deal()
    print(trader)
