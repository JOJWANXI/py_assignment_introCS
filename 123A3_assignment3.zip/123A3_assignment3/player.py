from __future__ import annotations

from cave import Cave
from material import Material
from trader import Trader
from food import Food
from random_gen import RandomGen
from referential_array import ArrayR
from heap import MaxHeap

# List taken from https://minecraft.fandom.com/wiki/Mob
PLAYER_NAMES = [
    "Steve",
    "Alex",
    "ɘᴎiɿdoɿɘH",
    "Allay",
    "Axolotl",
    "Bat",
    "Cat",
    "Chicken",
    "Cod",
    "Cow",
    "Donkey",
    "Fox",
    "Frog",
    "Glow Squid",
    "Horse",
    "Mooshroom",
    "Mule",
    "Ocelot",
    "Parrot",
    "Pig",
    "Pufferfish",
    "Rabbit",
    "Salmon",
    "Sheep",
    "Skeleton Horse",
    "Snow Golem",
    "Squid",
    "Strider",
    "Tadpole",
    "Tropical Fish",
    "Turtle",
    "Villager",
    "Wandering Trader",
    "Bee",
    "Cave Spider",
    "Dolphin",
    "Enderman",
    "Goat",
    "Iron Golem",
    "Llama",
    "Panda",
    "Piglin",
    "Polar Bear",
    "Spider",
    "Trader Llama",
    "Wolf",
    "Zombified Piglin",
    "Blaze",
    "Chicken Jockey",
    "Creeper",
    "Drowned",
    "Elder Guardian",
    "Endermite",
    "Evoker",
    "Ghast",
    "Guardian",
    "Hoglin",
    "Husk",
    "Magma Cube",
    "Phantom",
    "Piglin Brute",
    "Pillager",
    "Ravager",
    "Shulker",
    "Silverfish",
    "Skeleton",
    "Skeleton Horseman",
    "Slime",
    "Spider Jockey",
    "Stray",
    "Vex",
    "Vindicator",
    "Warden",
    "Witch",
    "Wither Skeleton",
    "Zoglin",
    "Zombie",
    "Zombie Villager",
    "H̴͉͙̠̥̹͕͌̋͐e̸̢̧̟͈͍̝̮̹̰͒̀͌̈̆r̶̪̜͙̗̠̱̲̔̊̎͊̑̑̚o̷̧̮̙̗̖̦̠̺̞̾̓͆͛̅̉̽͘͜͝b̸̨̛̟̪̮̹̿́̒́̀͋̂̎̕͜r̸͖͈͚̞͙̯̲̬̗̅̇̑͒͑ͅi̶̜̓̍̀̑n̴͍̻̘͖̥̩͊̅͒̏̾̄͘͝͝ę̶̥̺̙̰̻̹̓̊̂̈́̆́̕͘͝͝"
]

class Player():

    DEFAULT_EMERALDS = 50

    MIN_EMERALDS = 14
    MAX_EMERALDS = 40

    def __init__(self, name, emeralds=None) -> None:
        self.name = name
        self.balance = self.DEFAULT_EMERALDS if emeralds is None else emeralds
        self.traders = []
        self.foods = []
        self.materials = []
        self.caves = []

    def set_traders(self, traders_list: list[Trader]) -> None:
        self.traders = traders_list

    def set_foods(self, foods_list: list[Food]) -> None:
        self.foods = foods_list

    @classmethod
    def random_player(cls) -> Player:
        ran_player_name = str(RandomGen.random_choice(PLAYER_NAMES))
        return cls(ran_player_name)

    def set_materials(self, materials_list: list[Material]) -> None:
        self.materials = materials_list

    def set_caves(self, caves_list: list[Cave]) -> None:
        self.caves = caves_list

    def select_food_and_caves(self) -> tuple[Food | None, float, list[tuple[Cave, float]]]:
        # create a new array to store material associated information
        # (hunger_value, emerald_value)
        arr = ArrayR(len(self.materials))
        # set index to materials and set default values of information array,
        # the hunger value is mining rate of this material
        # and the emerald is set to 0
        # it takes O(M) time.
        for i in range(len(self.materials)):
            self.materials[i].index = i
            self.materials[i].max_emerald = 0
        # update emerald value by max trader's price
        # it takes O(T) time
        for trader in self.traders:
            if trader.is_currently_selling() and trader.current_price > trader.current_material.max_emerald:
                trader.current_material.max_emerald = trader.current_price

        # for every food, check if it will get the optimal balance
        # This outer loop takes O(F) time
        max_balance = self.balance
        max_food = None
        max_caves_list = []
        cur_balance = 0
        cur_hunger = 0
        cur_caves_list = []
        for food in self.foods:
            if self.balance < food.price:
                continue
            cur_caves_list.clear()
            cur_balance = self.balance - food.price
            cur_hunger = food.hunger_bars
            # create a cave heap to sort the caves by ratio max_emerald / hunger value
            # it takes O(C*logC) time
            cave_heap = MaxHeap(len(self.caves))
            for cave in self.caves:
                cave.priority_weight = cave.cave_material.max_emerald / cave.cave_material.mining_rate
                cave_heap.add(cave)
            # simulate the day, buy the material and sell
            # it takes O(C*logC) time
            while cave_heap.length > 0 and cur_hunger > 0:
                top_cave = cave_heap.get_max()
                if cur_hunger > top_cave.quantity * top_cave.cave_material.mining_rate:
                    # have enough hunger, buy all of them
                    buy_number = top_cave.quantity
                else:
                    # do not have enough hunger, buy part of them
                    buy_number = cur_hunger / top_cave.cave_material.mining_rate
                cur_hunger -= buy_number * top_cave.cave_material.mining_rate
                cur_balance += buy_number * top_cave.cave_material.max_emerald
                cur_caves_list.append((top_cave, buy_number))
            if cur_balance > max_balance:
                max_balance = cur_balance
                max_food = food
                max_caves_list = cur_caves_list.copy()
        # reset all the data, it takes O(M) time
        for i in range(len(self.materials)):
            self.materials[i].index = -1
            self.materials[i].max_emerald = 0
        return max_food, max_balance, max_caves_list

    def __str__(self) -> str:
        return "({},{})".format(self.name, self.balance)

if __name__ == "__main__":
    print(Player("Steve"))
    print(Player("Alex", emeralds=1000))
