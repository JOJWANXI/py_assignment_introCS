from random_gen import RandomGen

# Material names taken from https://minecraft-archive.fandom.com/wiki/Items
RANDOM_MATERIAL_NAMES = [
    "Arrow",
    "Axe",
    "Bow",
    "Bucket",
    "Carrot on a Stick",
    "Clock",
    "Compass",
    "Crossbow",
    "Exploration Map",
    "Fire Charge",
    "Fishing Rod",
    "Flint and Steel",
    "Glass Bottle",
    "Dragon's Breath",
    "Hoe",
    "Lead",
    "Map",
    "Pickaxe",
    "Shears",
    "Shield",
    "Shovel",
    "Sword",
    "Saddle",
    "Spyglass",
    "Totem of Undying",
    "Blaze Powder",
    "Blaze Rod",
    "Bone",
    "Bone meal",
    "Book",
    "Book and Quill",
    "Enchanted Book",
    "Bowl",
    "Brick",
    "Clay",
    "Coal",
    "Charcoal",
    "Cocoa Beans",
    "Copper Ingot",
    "Diamond",
    "Dyes",
    "Ender Pearl",
    "Eye of Ender",
    "Feather",
    "Spider Eye",
    "Fermented Spider Eye",
    "Flint",
    "Ghast Tear",
    "Glistering Melon",
    "Glowstone Dust",
    "Gold Ingot",
    "Gold Nugget",
    "Gunpowder",
    "Ink Sac",
    "Iron Ingot",
    "Iron Nugget",
    "Lapis Lazuli",
    "Leather",
    "Magma Cream",
    "Music Disc",
    "Name Tag",
    "Nether Bricks",
    "Paper",
    "Popped Chorus Fruit",
    "Prismarine Crystal",
    "Prismarine Shard",
    "Rabbit's Foot",
    "Rabbit Hide",
    "Redstone",
    "Seeds",
    "Beetroot Seeds",
    "Nether Wart Seeds",
    "Pumpkin Seeds",
    "Wheat Seeds",
    "Slimeball",
    "Snowball",
    "Spawn Egg",
    "Stick",
    "String",
    "Wheat",
    "Netherite Ingot",
]


class Material:
    """

    """

    def __init__(self, name: str, mining_rate: float) -> None:
        self.name = name
        self.mining_rate = mining_rate
        self.index = -1
        self.max_emerald = 0

    def __str__(self) -> str:
        return "[{}: {}🍗/💎]".format(self.name, self.mining_rate)

    @classmethod
    def random_material(cls):
        ran_ma = str(RandomGen.random_choice(RANDOM_MATERIAL_NAMES))
        return cls(ran_ma, 15 + 10 * RandomGen.random_float())

    @staticmethod
    def get_material_count():
        return len(RANDOM_MATERIAL_NAMES)

    @staticmethod
    def get_random_mining_rate():
        return 15 + 10 * RandomGen.random_float()

    def __lt__(self,other):
        return self.mining_rate < other.mining_rate

    def __le__(self,other):
        return self.mining_rate <= other.mining_rate

    def __gt__(self,other):
        return self.mining_rate > other.mining_rate

    def __ge__(self,other):
        return self.mining_rate >= other.mining_rate

if __name__ == "__main__":
    print(Material("Coal", 4.5))
