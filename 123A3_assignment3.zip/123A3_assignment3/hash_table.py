""" Hash Table ADT

Defines a Hash Table using Linear Probing for conflict resolution.
"""
from __future__ import annotations
from primes import LargestPrimeIterator

__author__ = 'Brendon Taylor. Modified by Graeme Gange, Alexey Ignatiev, and Jackson Goerner'
__docformat__ = 'reStructuredText'
__modified__ = '21/05/2020'
__since__ = '14/05/2020'


from referential_array import ArrayR
from typing import TypeVar, Generic
T = TypeVar('T')


class LinearProbeTable(Generic[T]):
    """
        Linear Probe Table.

        attributes:
            count: number of elements in the hash table
            table: used to represent our internal array
            tablesize: current size of the hash table
    """

    def __init__(self, expected_size: int, tablesize_override: int = -1) -> None:
        """
            Initialiser.
        """
        if tablesize_override == -1:
            self.primeGen = LargestPrimeIterator(expected_size * 3, 2)
            self.table_size = next(self.primeGen)
        else:
            self.table_size = tablesize_override

        self.table = ArrayR(self.table_size)
        self.count = 0
        # statics

        self.conflict_count = 0  # the total number of conflicts
        self.probe_total = 0  # the total distance probed throughout the execution of the code
        self.probe_max = 0  # the length of the longest probe chain throughout the execution of the code
        self.rehash_count = 0  # the total number of times rehashing is done

    def hash(self, key: str) -> int:
        """
            Hash a key for insertion into the hashtable.
        """
        # DJB2 hash function by Daniel J.Bernstein
        hash = 5381
        for i in range(len(key)):
            hash = (hash * 33) + ord(key[i])
        return hash % self.table_size

    def statistics(self) -> tuple:
        return (self.conflict_count, self.probe_total, self.probe_max, self.rehash_count)

    def __len__(self) -> int:
        """
            Returns number of elements in the hash table
            :complexity: O(1)
        """
        return self.count

    def _linear_probe(self, key: str, is_insert: bool) -> int:
        """
            Find the correct position for this key in the hash table using linear probing
            :complexity best: O(K) first position is empty
                            where K is the size of the key
            :complexity worst: O(K + N) when we've searched the entire table
                            where N is the tablesize
            :raises KeyError: When a position can't be found
        """
        position = self.hash(key)  # get the position using hash

        if is_insert and self.is_full():
            raise KeyError(key)

        probe_len = 0
        is_conflict = False
        for _ in range(len(self.table)):  # start traversing
            if self.table[position] is None:  # found empty slot
                if is_insert:
                    self.probe_max = max(self.probe_max, probe_len)
                    self.probe_total += probe_len
                    if is_conflict:
                        self.conflict_count += 1
                    return position
                else:
                    raise KeyError(key)  # so the key is not in
            elif self.table[position][0] == key:  # found key
                self.probe_max = max(self.probe_max, probe_len)
                self.probe_total += probe_len
                if is_conflict:
                    self.conflict_count += 1
                return position
            else:  # there is something but not the key, try next
                position = (position + 1) % len(self.table)
                probe_len += 1
                is_conflict = True

        raise KeyError(key)

    def keys(self) -> list[str]:
        """
            Returns all keys in the hash table.
        """
        res = []
        for x in range(len(self.table)):
            if self.table[x] is not None:
                res.append(self.table[x][0])
        return res

    def values(self) -> list[T]:
        """
            Returns all values in the hash table.
        """
        res = []
        for x in range(len(self.table)):
            if self.table[x] is not None:
                res.append(self.table[x][1])
        return res

    def __contains__(self, key: str) -> bool:
        """
            Checks to see if the given key is in the Hash Table
            :see: #self.__getitem__(self, key: str)
        """
        try:
            _ = self[key]
        except KeyError:
            return False
        else:
            return True

    def __getitem__(self, key: str) -> T:
        """
            Get the item at a certain key
            :see: #self._linear_probe(key: str, is_insert: bool)
            :raises KeyError: when the item doesn't exist
        """
        position = self._linear_probe(key, False)
        return self.table[position][1]

    def __setitem__(self, key: str, data: T) -> None:
        """
            Set an (key, data) pair in our hash table
            :see: #self._linear_probe(key: str, is_insert: bool)
            :see: #self.__contains__(key: str)
        """
        if self.is_full() and key not in self:
            raise ValueError("The hash table is full!")

        if self.count * 2 > self.table_size:
            self._rehash()

        position = self._linear_probe(key, True)

        if self.table[position] is None:
            self.count += 1

        self.table[position] = (key, data)

    def is_empty(self):
        """
            Returns whether the hash table is empty
            :complexity: O(1)
        """
        return self.count == 0

    def is_full(self):
        """
            Returns whether the hash table is full
            :complexity: O(1)
        """
        return self.count == len(self.table)

    def insert(self, key: str, data: T) -> None:
        """
            Utility method to call our setitem method
            :see: #__setitem__(self, key: str, data: T)
        """
        self[key] = data

    def _rehash(self) -> None:
        """
            Need to resize table and reinsert all values
        """
        self.rehash_count += 1

        num = self.count * 2
        new_size = self.table_size

        while new_size <= num * 2:
            new_size *= 3
            self.primeGen = LargestPrimeIterator(new_size, 2)
            new_size = next(self.primeGen)

        old_table = self.table

        self.table_size = new_size
        self.count = 0
        # create new table
        self.table = ArrayR(self.table_size)
        for i in range(len(old_table)):  # start traversing
            if old_table[i] is not None:  # found empty slot
                self.insert(old_table[i][0], old_table[i][1])

    def __str__(self) -> str:
        """
            Returns all they key/value pairs in our hash table (no particular
            order).
            :complexity: O(N) where N is the table size
        """
        result = ""
        for item in self.table:
            if item is not None:
                (key, value) = item
                result += "(" + str(key) + "," + str(value) + ")\n"
        return result
