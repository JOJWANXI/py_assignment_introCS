""""""

from math import sqrt, log, ceil
from random import randrange, getrandbits

__author__ = ''
__docformat__ = 'reStructuredText'


def isPrime(n):
    for i in range(2, int(sqrt(n)) + 1):
        if n % i == 0:
            return False

    return True


class LargestPrimeIterator:

    def __init__(self, upper_bound, factor):
        self.upper_bound = upper_bound
        self.factor = factor

        self.p = 0

    def __iter__(self):
        return self

    def __next__(self):

        for i in range(self.upper_bound - 1, -1, -1):
            if isPrime(i):
                self.p = i
                break

        self.upper_bound = self.p * self.factor
        return self.p